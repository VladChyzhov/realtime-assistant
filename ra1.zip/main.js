require('dotenv/config');
const { app, BrowserWindow, ipcMain, globalShortcut, desktopCapturer, session } = require('electron');
const path = require('path');
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const { createSystemAudioCapture } = require('./utils/audioCapture.js');
const { createVadProcessor } = require('./utils/vad.js');
const { createOpenAIStream } = require('./utils/openai.js');

let mainWindow;
let audioCapture = null;
let vadProcessor = null;
let openAIStream = null;
let expressApp;
let server;
let io;

// Разрешаем доступ к media и display-capture
app.whenReady().then(() => {
  try {
    session.defaultSession.setPermissionRequestHandler((_wc, permission, callback) => {
      // Разрешаем media и display-capture для getDisplayMedia/desktop capture
      if (permission === 'media' || permission === 'display-capture') return callback(true);
      return callback(false);
    });
  } catch {}
});

function createServer() {
  expressApp = express();
  expressApp.use(express.json());
  expressApp.use(express.static(path.join(__dirname, 'public')));

  // CORS
  expressApp.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
  });

  // WebRTC SDP proxy → OpenAI
  expressApp.post('/webrtc/sdp', express.text({ type: '*/*' }), async (req, res) => {
    try {
      const offerSdp = req.body;
      if (!offerSdp) return res.status(400).send('Empty SDP');
      const model = (req.query && req.query.model) ? String(req.query.model) : 'gpt-4o-realtime-preview-2024-12-17';
      const fetch = (await import('node-fetch')).default;
      const r = await fetch(`https://api.openai.com/v1/realtime?model=${encodeURIComponent(model)}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/sdp'
        },
        body: offerSdp
      });
      if (!r.ok) {
        const t = await r.text();
        console.error('OpenAI SDP error:', r.status, t);
        return res.status(r.status).send(t);
      }
      const answerSdp = await r.text();
      res.set('Content-Type', 'application/sdp');
      return res.status(200).send(answerSdp);
    } catch (e) {
      console.error('SDP proxy error', e);
      return res.status(500).send('SDP proxy error');
    }
  });

  // Простые статусы
  expressApp.get('/api/status', (_req, res) => {
    res.json({ status: 'running', audioCapture: !!audioCapture, vad: !!vadProcessor, openai: !!openAIStream, timestamp: Date.now() });
  });

  server = http.createServer(expressApp);
  io = socketIo(server, { cors: { origin: '*', methods: ['GET', 'POST'] } });

  io.on('connection', (socket) => {
    console.log('🌐 WebSocket подключен:', socket.id);
    socket.emit('status', { audioCapture: !!audioCapture, vad: !!vadProcessor, openai: !!openAIStream });
    socket.on('disconnect', () => console.log('🔌 WebSocket отключен:', socket.id));
  });

  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => {
    console.log(`🚀 HTTP сервер на http://localhost:${PORT}`);
  });
}

function sendToRenderer(channel, data) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    try {
      const wc = mainWindow.webContents;
      if (wc && !wc.isDestroyed()) wc.send(channel, data);
      return;
    } catch (err) {
      console.warn(`⚠️ Не удалось отправить в рендерер: ${err.message}`);
    }
  }
  console.warn('⚠️ Рендерер недоступен, сообщение пропущено:', channel);
}

async function startAudioCapture() {
  console.log('🎵 Запуск WS-режима...');
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error('OPENAI_API_KEY не установлен');
  const model = process.env.OPENAI_MODEL || 'gpt-4o-realtime-preview';

  try {
    // Захват системного звука (мок внутри utils/audioCapture.js)
    audioCapture = await createSystemAudioCapture();
    vadProcessor = createVadProcessor(audioCapture.processedStream, {
      speechThreshold: parseFloat(process.env.VAD_SPEECH_THRESHOLD) || 0.008,
      silenceThreshold: parseFloat(process.env.VAD_SILENCE_THRESHOLD) || 0.003,
      silenceFrames: parseInt(process.env.VAD_SILENCE_FRAMES) || 15
    });

    openAIStream = createOpenAIStream(model, apiKey, vadProcessor, {
      systemPrompt: require('./utils/prompt.js').SYSTEM_PROMPT
    });

    // Хендлеры
    if (audioCapture) {
      audioCapture.on('ready', () => sendToRenderer('audio-capture-ready', { timestamp: Date.now() }));
      audioCapture.on('audio-data', (data) => {
        openAIStream?.sendAudioData(data);
        io?.emit('audio-data', { size: data?.size || 0, timestamp: Date.now() });
      });
      audioCapture.on('error', (error) => sendToRenderer('error', { error: error.message, timestamp: Date.now() }));
      await audioCapture.start();
    }

    if (openAIStream) {
      openAIStream.on('ready', () => sendToRenderer('openai-ready', { timestamp: Date.now() }));
      openAIStream.on('stream-activated', () => sendToRenderer('openai-stream-activated', { timestamp: Date.now() }));
      openAIStream.on('stream-deactivated', () => sendToRenderer('openai-stream-deactivated', { timestamp: Date.now() }));
      openAIStream.on('transcript', (data) => sendToRenderer('transcript', data));
      openAIStream.on('response', (data) => sendToRenderer('response', data));
      openAIStream.on('error', (error) => sendToRenderer('error', { error: error.message, timestamp: Date.now() }));
      openAIStream.on('model-changed', (modelName) => sendToRenderer('model-changed', { model: modelName, timestamp: Date.now() }));
    }

    io?.emit('audio-capture-started', { timestamp: Date.now() });
  } catch (error) {
    console.error('❌ Ошибка старта WS-режима:', error);
    throw error;
  }
}

async function stopAudioCapture() {
  try {
    openAIStream?.close();
    openAIStream = null;
    vadProcessor?.close();
    vadProcessor = null;
    if (audioCapture) { try { audioCapture.stop(); } catch {} audioCapture = null; }
    io?.emit('audio-capture-stopped', { timestamp: Date.now() });
  } catch (error) {
    console.error('❌ Ошибка остановки WS-режима:', error);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    title: 'Realtime AI Assistant',
    show: false
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    console.log('🪟 Окно показано');
  });

  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools();
  }

  // Отладка загрузки окна
  mainWindow.webContents.on('did-finish-load', () => {
    console.log('✅ Renderer: did-finish-load');
  });
  mainWindow.webContents.on('did-fail-load', (_e, errorCode, errorDescription, validatedURL) => {
    console.error('❌ Renderer: did-fail-load', { errorCode, errorDescription, validatedURL });
  });

  // Диагностика падений
  app.on('render-process-gone', (_event, _wc, details) => {
    console.error('🔻 render-process-gone:', details);
  });
  app.on('child-process-gone', (_event, details) => {
    console.error('🔻 child-process-gone:', details);
  });
  mainWindow.webContents.on('render-process-gone', (_e, details) => {
    console.error('🔻 webContents render-process-gone:', details);
    stopAudioCapture().catch(() => {});
  });

  mainWindow.webContents.on('did-start-loading', () => {
    stopAudioCapture().catch(() => {});
  });

  mainWindow.on('closed', () => {
    stopAudioCapture().catch(() => {});
    mainWindow = null;
  });
}

function registerGlobalShortcuts() {
  globalShortcut.register('CommandOrControl+Shift+A', async () => {
    try {
      if (audioCapture && audioCapture.isRecording) {
        await stopAudioCapture();
      } else {
        await startAudioCapture();
      }
    } catch (error) {
      console.error('❌ Ошибка переключения WS-режима:', error);
    }
  });

  globalShortcut.register('CommandOrControl+Shift+M', () => {
    if (openAIStream) {
      const currentModel = openAIStream.model;
      const newModel = currentModel === 'gpt-4o-realtime-preview' ? 'gpt-4o-mini-realtime-preview' : 'gpt-4o-realtime-preview';
      openAIStream.switchModel(newModel);
    }
  });
}

// IPC
ipcMain.handle('get-system-prompt', async () => {
  try { return require('./utils/prompt.js').SYSTEM_PROMPT; } catch { return 'Ты — помощник для живого собеседования. Кратко и по делу.'; }
});
ipcMain.handle('get-status', () => ({ audioCapture: !!audioCapture, vad: !!vadProcessor, openai: !!openAIStream, timestamp: Date.now() }));
ipcMain.handle('get-desktop-sources', async (_event, options) => {
  const sources = await desktopCapturer.getSources({ types: options?.types || ['screen', 'window'], thumbnailSize: { width: 160, height: 90 }, fetchWindowIcons: true });
  return sources.map(s => ({ id: s.id, name: s.name }));
});
ipcMain.handle('get-api-key', () => process.env.OPENAI_API_KEY || '');
ipcMain.handle('start-audio-capture', async () => { try { await startAudioCapture(); return { success: true }; } catch (e) { return { success: false, error: e.message }; } });
ipcMain.handle('stop-audio-capture', async () => { try { await stopAudioCapture(); return { success: true }; } catch (e) { return { success: false, error: e.message }; } });
ipcMain.handle('switch-model', (_e, model) => { if (openAIStream) { openAIStream.switchModel(model); return { success: true }; } return { success: false, error: 'OpenAI поток не активен' }; });
ipcMain.handle('get-current-model', () => openAIStream ? openAIStream.model : (process.env.OPENAI_MODEL || 'gpt-4o-realtime-preview'));

ipcMain.on('audio-chunk', (_e, base64Pcm16) => { try { openAIStream?.ingestBase64Pcm16(base64Pcm16); } catch (err) { console.error('❌ Ошибка приема аудио чанка:', err); } });
ipcMain.on('vad-event', (_e, payload) => {
  io?.emit('vad', payload);
  if (!openAIStream || !payload?.type) return;
  try {
    if (payload.type === 'speech-start') openAIStream.handleVADEvent('speech-start');
    else if (payload.type === 'speech-end') openAIStream.handleVADEvent('speech-end');
  } catch (err) { console.error('❌ Ошибка обработки VAD:', err); }
});

// App lifecycle
app.whenReady().then(() => {
  console.log('🚀 Приложение готово');
  createServer();
  createWindow();
  registerGlobalShortcuts();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', async () => {
  try { await stopAudioCapture(); } catch {}
  try { server?.close(); } catch {}
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', async () => {
  try { await stopAudioCapture(); } catch {}
  globalShortcut.unregisterAll();
});

process.on('uncaughtException', (error) => console.error('❌ uncaughtException:', error));
process.on('unhandledRejection', (reason) => console.error('❌ unhandledRejection:', reason));
// placeholder