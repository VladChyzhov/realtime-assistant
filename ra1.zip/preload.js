const { contextBridge, ipcRenderer } = require('electron');

// Экспортируем безопасный API для renderer процесса
contextBridge.exposeInMainWorld('electronAPI', {
  // Ключ и модель
  getApiKey: () => ipcRenderer.invoke('get-api-key'),
  getCurrentModel: () => ipcRenderer.invoke('get-current-model'),
  getSystemPrompt: () => ipcRenderer.invoke('get-system-prompt'),

  // Источники захвата рабочего стола (desktopCapturer через main)
  // Получение источников только через безопасный IPC в main-процесс
  getDesktopSources: (options = { types: ['screen', 'window'] }) => ipcRenderer.invoke('get-desktop-sources', options),

  // Управление WS-режимом (fallback)
  startAudioCapture: () => ipcRenderer.invoke('start-audio-capture'),
  stopAudioCapture: () => ipcRenderer.invoke('stop-audio-capture'),

  // Переключение модели в WS-режиме
  switchModel: (model) => ipcRenderer.invoke('switch-model', model),

  // Передача аудиоданных и VAD-событий в main
  sendAudioChunk: (base64Pcm16) => ipcRenderer.send('audio-chunk', base64Pcm16),
  sendVADEvent: (type, payload = {}) => ipcRenderer.send('vad-event', { type, ...payload }),

  // Подписка/отписка на события из main
  on: (channel, callback) => {
    const validChannels = [
      'vad', 'transcript', 'response', 'error',
      'connected', 'disconnected', 'stream-activated', 'stream-deactivated',
      'openai-ready', 'openai-stream-activated', 'openai-stream-deactivated',
      'model-changed', 'audio-capture-ready', 'audio-capture-started', 'audio-capture-stopped'
    ];
    if (!validChannels.includes(channel)) return;
    ipcRenderer.on(channel, (_event, ...args) => callback(...args));
  },
  removeAllListeners: (channel) => {
    const validChannels = [
      'vad', 'transcript', 'response', 'error',
      'connected', 'disconnected', 'stream-activated', 'stream-deactivated',
      'openai-ready', 'openai-stream-activated', 'openai-stream-deactivated',
      'model-changed', 'audio-capture-ready', 'audio-capture-started', 'audio-capture-stopped'
    ];
    if (validChannels.includes(channel)) ipcRenderer.removeAllListeners(channel);
  },

  // URL локального сервера (Express) для WebRTC сигналинга
  getServerUrl: () => `http://localhost:${process.env.PORT || 3000}`,
});

console.log('🔌 Preload скрипт загружен');
// placeholder