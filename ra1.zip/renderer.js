const USE_WEBRTC = true;

let mediaStream = null;
let audioContext = null;
let processorNode = null;
let selectedSourceId = null;
let running = false;

let rtcPc = null;
let rtcData = null;
let rtcLocalStream = null;

async function getSystemAudioStreamForWebRTC() {
  // 1) Пытаемся через getDisplayMedia (без IPC)
  try {
    const s2 = await navigator.mediaDevices.getDisplayMedia({ audio: true, video: true });
    s2.getVideoTracks().forEach(t => t.stop());
    return new MediaStream(s2.getAudioTracks());
  } catch (e2) {
    console.warn('getDisplayMedia(audio:true) не удался, пробуем desktop-режим', e2?.message);
  }

  // 2) Если не получилось — тогда уже пробуем desktop-режим без IPC (без chromeMediaSourceId)
  const constraints = {
    audio: {
      mandatory: {
        chromeMediaSource: 'desktop',
      }
    },
    video: false
  };
  const s = await navigator.mediaDevices.getUserMedia(constraints);
  return s;
}

function waitForIceComplete(pc) {
  return new Promise(res => {
    if (pc.iceGatheringState === 'complete') return res();
    const onchg = () => {
      if (pc.iceGatheringState === 'complete') {
        pc.removeEventListener('icegatheringstatechange', onchg);
        res();
      }
    };
    pc.addEventListener('icegatheringstatechange', onchg);
  });
}

async function startRealtimeSystemAudioWebRTC() {
  if (rtcPc) return;
  updateStatus('🔐 Запрашиваем доступ к системному аудио...', 'info');

  // 1) Сначала получаем поток аудио (покажет системный диалог)
  rtcLocalStream = await getSystemAudioStreamForWebRTC();

  // 2) Затем настраиваем RTCPeerConnection и DataChannel
  rtcPc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
  rtcData = rtcPc.createDataChannel('oai-events');
  rtcData.onopen = async () => {
    let instr = 'Ты — помощник. Отвечай кратко и по делу.';
    try { instr = await (window.electronAPI?.getSystemPrompt?.() ?? Promise.resolve(instr)); } catch {}
    const sessionUpdate = { type: 'session.update', session: { instructions: instr, turn_detection: { type: 'server_vad' } } };
    try { rtcData.send(JSON.stringify(sessionUpdate)); } catch {}
  };
  rtcData.onmessage = (ev) => {
    try {
      const msg = JSON.parse(ev.data);
      if (msg.type === 'response.output_text.delta') {
        const el = document.getElementById('asrText');
        if (el) el.textContent = (el.textContent || '') + (msg.delta || '');
      }
      if (msg.type === 'response.output_text.done') {
        const respEl = document.getElementById('responses');
        if (respEl) respEl.textContent = String(1 + (+respEl.textContent||0));
      }
      if (msg.type === 'input_audio_buffer.speech_started') updateStatus('🎤 Начало речи (система)', 'working');
      if (msg.type === 'input_audio_buffer.speech_stopped') updateStatus('🛑 Конец речи, генерируем ответ...', 'working');
    } catch {}
  };

  // 3) Прикрепляем треки
  rtcLocalStream.getAudioTracks().forEach(t => rtcPc.addTrack(t, rtcLocalStream));

  // 4) Создаём оффер и получаем answer через локальный proxy
  const offer = await rtcPc.createOffer({ offerToReceiveAudio: false, offerToReceiveVideo: false });
  await rtcPc.setLocalDescription(offer);
  await waitForIceComplete(rtcPc);
  const modelSelect = document.getElementById('modelSelect');
  const model = modelSelect ? modelSelect.value : 'gpt-4o-realtime-preview-2024-12-17';
  const baseUrl = window.electronAPI?.getServerUrl?.() || 'http://localhost:3000';
  const sdpAnswer = await fetch(`${baseUrl}/webrtc/sdp?model=${encodeURIComponent(model)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/sdp' },
    body: rtcPc.localDescription?.sdp || ''
  }).then(r => r.ok ? r.text() : Promise.reject(new Error('SDP proxy ' + r.status)));
  await rtcPc.setRemoteDescription({ type: 'answer', sdp: sdpAnswer });
  running = true;
  updateStatus('🔗 WebRTC подключен (system audio → OpenAI)', 'ok');
}

async function stopRealtimeSystemAudioWebRTC() {
  try {
    rtcPc?.getSenders().forEach(s => { try { s.track?.stop(); } catch {} });
    rtcPc?.getReceivers().forEach(r => { try { r.track?.stop(); } catch {} });
    rtcPc?.close();
  } catch {}
  rtcPc = null;
  if (rtcLocalStream) {
    rtcLocalStream.getTracks().forEach(t => t.stop());
    rtcLocalStream = null;
  }
  running = false;
  updateStatus('⏹ WebRTC остановлен', 'info');
}

function updateStatus(message, type = 'info') {
  const statusEl = document.getElementById('status');
  if (statusEl) {
    statusEl.textContent = message;
    statusEl.className = `status ${type}`;
  }
  console.log(`📊 Статус: ${message}`);
}

async function startTranscription() {
  try {
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    if (startBtn) { startBtn.textContent = 'Запуск...'; startBtn.disabled = true; }
    updateStatus('🎯 Начинаем...', 'info');

    if (USE_WEBRTC) {
      await startRealtimeSystemAudioWebRTC();
      if (startBtn) { startBtn.style.display = 'none'; startBtn.disabled = true; }
      if (stopBtn) { stopBtn.style.display = 'inline-block'; stopBtn.disabled = false; }
      return;
    }
  } catch (e) {
    console.error(e);
    updateStatus('❌ Ошибка старта: ' + (e?.message || e), 'error');
  }
}

async function stopTranscription() {
  try {
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');

    if (USE_WEBRTC) {
      await stopRealtimeSystemAudioWebRTC();
      if (startBtn) { startBtn.style.display = 'inline-block'; startBtn.disabled = false; }
      if (stopBtn) { stopBtn.style.display = 'none'; stopBtn.disabled = true; }
      return;
    }
  } catch (e) {
    console.error(e);
    updateStatus('❌ Ошибка остановки: ' + (e?.message || e), 'error');
  }
}

async function switchModel() {
  try {
    const modelSelect = document.getElementById('modelSelect');
    if (!modelSelect) return;
    const currentModel = modelSelect.value;
    const newModel = currentModel === 'gpt-4o-mini-realtime-preview' ? 'gpt-4o-mini-realtime-preview' : 'gpt-4o-realtime-preview';
    modelSelect.value = newModel;
    // В WS-режиме отправляем в main, в WebRTC – применяется на следующем старте
    if (window.electronAPI?.switchModel) {
      try { await window.electronAPI.switchModel(newModel); } catch {}
    }
    updateStatus(`🔄 Модель: ${newModel}`, 'success');
  } catch (error) {
    console.error('❌ Ошибка переключения модели:', error);
    updateStatus(`❌ Ошибка переключения: ${error.message}`, 'error');
  }
}

function onModelChange() {
  const modelSelect = document.getElementById('modelSelect');
  if (modelSelect) updateStatus(`📋 Модель изменена на: ${modelSelect.value}`, 'info');
}

function setupEventListeners() {
  if (!window.electronAPI?.on) return;
  window.electronAPI.on('transcript', (data) => {
    const asrText = document.getElementById('asrText');
    if (asrText) asrText.textContent = data.text || 'Речь распознана';
    updateStatus('🎙️ Речь распознана!', 'working');
  });
  window.electronAPI.on('response', (data) => {
    const parsed = data.parsed || {};
    if (parsed.RU) { const el = document.getElementById('ans-RU'); if (el) el.textContent = parsed.RU; }
    if (parsed.EN) { const el = document.getElementById('ans-EN'); if (el) el.textContent = parsed.EN; }
    if (parsed.SV) { const el = document.getElementById('ans-SV'); if (el) el.textContent = parsed.SV; }
    updateStatus('🤖 Ответ сгенерирован!', 'success');
  });
  window.electronAPI.on('error', (data) => {
    updateStatus(`❌ Ошибка: ${data.error}`, 'error');
  });
}

document.addEventListener('DOMContentLoaded', () => {
  console.log('🚀 DOM загружен, инициализация приложения...');
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const modelBtn = document.getElementById('modelBtn');
  const modelSelect = document.getElementById('modelSelect');
  const sourceSelect = document.getElementById('sourceSelect');

  if (startBtn) startBtn.onclick = startTranscription;
  if (stopBtn) stopBtn.onclick = stopTranscription;
  if (modelBtn) modelBtn.onclick = switchModel;
  if (modelSelect) modelSelect.onchange = onModelChange;
  if (sourceSelect) sourceSelect.onchange = (e) => { selectedSourceId = e.target.value; };

  updateStatus('Готов к запуску. Выберите модель и нажмите Start.', 'info');
  try { setupEventListeners(); } catch {}
});
// placeholder