// Убираем все require - они не работают в renderer процессе с contextIsolation
// Вместо этого используем window.electronAPI через preload.js

let mediaStream = null;
let audioContext = null;
let processorNode = null;
let selectedSourceId = null;
let running = false;

// Функция для работы с main процессом через preload API
async function getApiKey() {
  try {
    if (window.electronAPI) {
      return await window.electronAPI.getApiKey();
    }
    
    // Для тестирования используем значение по умолчанию
    return 'sk-your-api-key-here';
  } catch (error) {
    console.error('Ошибка получения API ключа:', error);
    return null;
  }
}

// Ждем загрузки DOM перед получением элементов
document.addEventListener('DOMContentLoaded', () => {
  console.log('🚀 DOM загружен, инициализация приложения...');
  
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const modelBtn = document.getElementById('modelBtn');
  const modelSelect = document.getElementById('modelSelect');
  const sourceSelect = document.getElementById('sourceSelect');
  
  if (startBtn) startBtn.onclick = startTranscription;
  if (stopBtn) stopBtn.onclick = stopTranscription;
  if (modelBtn) modelBtn.onclick = switchModel;
  if (modelSelect) modelSelect.onchange = onModelChange;
  if (sourceSelect) sourceSelect.onchange = (e) => { selectedSourceId = e.target.value; };
  populateSources();
  
  updateStatus('Готов к запуску. Выберите модель и нажмите Start.', 'info');
});

function updateStatus(message, type = 'info') {
  const statusEl = document.getElementById('status');
  if (statusEl) {
    statusEl.textContent = message;
    statusEl.className = `status ${type}`;
  }
  console.log(`📊 Статус: ${message}`);
}

async function startTranscription() {
  try {
    // Сразу показываем что кнопка нажата
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    
    if (startBtn) {
      startBtn.textContent = 'Запуск...';
      startBtn.disabled = true;
    }
    
    updateStatus('🎯 Начинаем захват звука...', 'info');
    
    // Получаем выбранную модель
    const modelSelect = document.getElementById('modelSelect');
    const MODEL = modelSelect ? modelSelect.value : 'gpt-4o-realtime-preview';
    console.log('📋 Выбранная модель:', MODEL);
    updateStatus(`📋 Модель: ${MODEL}`, 'info');
    
    // Используем Electron API для запуска захвата
    if (window.electronAPI) {
      try {
        const result = await window.electronAPI.startAudioCapture();
        if (result.success) {
          updateStatus('✅ Захват звука запущен!', 'success');
          
          // Показываем кнопку остановки
          if (stopBtn) stopBtn.style.display = 'inline-block';
          if (startBtn) startBtn.style.display = 'none';
          
          // Настраиваем слушатели событий
          setupEventListeners();

          // Запускаем локальный захват системного звука в renderer для минимальной задержки
          await startSystemAudioCapture();
          
        } else {
          updateStatus(`❌ Ошибка: ${result.error}`, 'error');
          resetUI();
        }
      } catch (error) {
        console.error('❌ Ошибка IPC:', error);
        updateStatus(`❌ Ошибка IPC: ${error.message}`, 'error');
        resetUI();
      }
    } else {
      updateStatus('❌ Electron API недоступен', 'error');
      resetUI();
    }
    
  } catch (error) {
    console.error('❌ Ошибка запуска транскрипции:', error);
    updateStatus(`❌ Ошибка: ${error.message}`, 'error');
    resetUI();
  }
}

function setupEventListeners() {
  if (!window.electronAPI) return;
  
  // Слушаем события от main процесса
  window.electronAPI.on('transcript', (data) => {
    console.log('📝 Транскрипция:', data);
    const asrText = document.getElementById('asrText');
    if (asrText) asrText.textContent = data.text || 'Речь распознана';
    updateStatus('🎙️ Речь распознана!', 'working');
  });
  
  window.electronAPI.on('response', (data) => {
    console.log('💬 Ответ:', data);
    const parsed = data.parsed || {};
    
    // Обновляем ответы на разных языках
    if (parsed.RU) {
      const el = document.getElementById('ans-RU');
      if (el) el.textContent = parsed.RU;
    }
    if (parsed.EN) {
      const el = document.getElementById('ans-EN');
      if (el) el.textContent = parsed.EN;
    }
    if (parsed.SV) {
      const el = document.getElementById('ans-SV');
      if (el) el.textContent = parsed.SV;
    }
    
    updateStatus('🤖 Ответ сгенерирован!', 'success');
  });
  
  window.electronAPI.on('error', (data) => {
    console.error('❌ Ошибка:', data);
    updateStatus(`❌ Ошибка: ${data.error}`, 'error');
  });
  
  window.electronAPI.on('vad', (data) => {
    console.log('🎤 VAD событие:', data);
  });
}

function resetUI() {
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  
  if (startBtn) {
    startBtn.textContent = 'Запустить захват';
    startBtn.disabled = false;
    startBtn.style.display = 'inline-block';
  }
  
  if (stopBtn) stopBtn.style.display = 'none';
  
  updateStatus('Готов к запуску. Выберите модель и нажмите Start.', 'info');
}

async function stopTranscription() {
  try {
    updateStatus('🛑 Останавливаем захват звука...', 'info');
    
    await stopSystemAudioCapture();
    if (window.electronAPI) {
      const result = await window.electronAPI.stopAudioCapture();
      if (result.success) {
        updateStatus('✅ Захват звука остановлен', 'success');
        resetUI();
      } else {
        updateStatus(`❌ Ошибка остановки: ${result.error}`, 'error');
      }
    } else {
      updateStatus('❌ Electron API недоступен', 'error');
    }
    
  } catch (error) {
    console.error('❌ Ошибка остановки:', error);
    updateStatus(`❌ Ошибка остановки: ${error.message}`, 'error');
  }
}

async function switchModel() {
  try {
    const modelSelect = document.getElementById('modelSelect');
    if (!modelSelect) return;
    
    const currentModel = modelSelect.value;
    const newModel = currentModel === 'gpt-4o-realtime-preview' 
      ? 'gpt-4o-mini-realtime-preview' 
      : 'gpt-4o-realtime-preview';
    
    modelSelect.value = newModel;
    
    if (window.electronAPI) {
      const result = await window.electronAPI.switchModel(newModel);
      if (result.success) {
        updateStatus(`🔄 Модель переключена на: ${newModel}`, 'success');
      } else {
        updateStatus(`❌ Ошибка переключения: ${result.error}`, 'error');
      }
    }
    
  } catch (error) {
    console.error('❌ Ошибка переключения модели:', error);
    updateStatus(`❌ Ошибка переключения: ${error.message}`, 'error');
  }
}

function onModelChange() {
  const modelSelect = document.getElementById('modelSelect');
  if (modelSelect) {
    const selectedModel = modelSelect.value;
    updateStatus(`📋 Модель изменена на: ${selectedModel}`, 'info');
  }
}

// Функция для открытия DevTools (если нужно)
function openDevTools() {
  if (window.electronAPI) {
    // Можно добавить IPC вызов для открытия DevTools
    console.log('Открытие DevTools...');
  }
}

// Источники экрана/окна для захвата системного аудио
async function populateSources() {
  try {
    if (!window.electronAPI) return;
    const sources = await window.electronAPI.getDesktopSources({ types: ['screen', 'window'] });
    const sourceSelect = document.getElementById('sourceSelect');
    if (sourceSelect) {
      sourceSelect.innerHTML = '';
      for (const s of sources) {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.name;
        sourceSelect.appendChild(opt);
      }
    }
    if (sources.length > 0) {
      selectedSourceId = sources[0].id;
      if (sourceSelect) sourceSelect.value = selectedSourceId;
    }
  } catch (e) {
    console.error('Ошибка загрузки источников:', e);
  }
}

async function startSystemAudioCapture() {
  try {
    if (!selectedSourceId) {
      await populateSources();
    }
    // Для desktop audio в Chromium требуется указывать и video, и audio с одинаковым sourceId
    // Первичная попытка: и audio, и video с одним sourceId
    let constraints = {
      audio: {
        mandatory: {
          chromeMediaSource: 'desktop',
          chromeMediaSourceId: selectedSourceId
        }
      },
      video: {
        mandatory: {
          chromeMediaSource: 'desktop',
          chromeMediaSourceId: selectedSourceId
        }
      }
    };

    try {
      mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
    } catch (err) {
      console.warn('Первый способ захвата не удался, пробуем audio без sourceId:', err?.message);
      // Фоллбэк: video с id, audio без id
      constraints = {
        audio: { mandatory: { chromeMediaSource: 'desktop' } },
        video: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: selectedSourceId
          }
        }
      };
      mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
    }
    audioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 48000 });
    const source = audioContext.createMediaStreamSource(mediaStream);
    const gain = audioContext.createGain();
    gain.gain.value = 1.0;
    source.connect(gain);

    const bufferSize = 2048;
    processorNode = audioContext.createScriptProcessor(bufferSize, 1, 1);
    gain.connect(processorNode);
    // Подключаем к «тихому» выходу, чтобы граф был активен, но без звука
    const nullGain = audioContext.createGain();
    nullGain.gain.value = 0;
    processorNode.connect(nullGain);
    nullGain.connect(audioContext.destination);

    let vadEnergy = 0;
    let speaking = false;
    let silenceFrames = 0;
    const silenceFramesLimit = 10;
    const speechThreshold = 0.005;
    const queue = [];

    processorNode.onaudioprocess = (e) => {
      const data = e.inputBuffer.getChannelData(0);
      // VAD по RMS
      let sum = 0;
      for (let i = 0; i < data.length; i++) sum += data[i] * data[i];
      const rms = Math.sqrt(sum / data.length);
      vadEnergy = 0.9 * vadEnergy + 0.1 * rms;

      if (vadEnergy > speechThreshold) {
        if (!speaking) {
          speaking = true;
          silenceFrames = 0;
          window.electronAPI?.sendVADEvent('speech-start', { level: vadEnergy });
        }
      } else if (speaking) {
        silenceFrames++;
        if (silenceFrames > silenceFramesLimit) {
          speaking = false;
          window.electronAPI?.sendVADEvent('speech-end', { level: vadEnergy });
        }
      }

      // Ресемплинг 48k -> 16k (простое децимирование)
      const decimated = new Float32Array(Math.floor(data.length / 3));
      for (let i = 0, j = 0; i < data.length; i += 3, j++) decimated[j] = data[i];
      const pcm16 = floatTo16BitPCM(decimated);
      const b64 = base64FromArrayBuffer(pcm16.buffer);
      queue.push(b64);

      // Отправляем маленькие чанки чаще
      while (queue.length > 0) {
        const chunk = queue.shift();
        window.electronAPI?.sendAudioChunk(chunk);
      }
    };

    running = true;
  } catch (error) {
    console.error('Ошибка запуска системного аудиозахвата:', error);
  }
}

async function stopSystemAudioCapture() {
  try {
    running = false;
    if (processorNode) {
      try { processorNode.disconnect(); } catch {}
      processorNode.onaudioprocess = null;
      processorNode = null;
    }
    if (audioContext) {
      try { await audioContext.close(); } catch {}
      audioContext = null;
    }
    if (mediaStream) {
      mediaStream.getTracks().forEach(t => t.stop());
      mediaStream = null;
    }
  } catch (e) {
    console.error('Ошибка остановки аудиозахвата:', e);
  }
}

function floatTo16BitPCM(float32Array) {
  const len = float32Array.length;
  const buffer = new ArrayBuffer(len * 2);
  const view = new DataView(buffer);
  let offset = 0;
  for (let i = 0; i < len; i++, offset += 2) {
    let s = Math.max(-1, Math.min(1, float32Array[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Int16Array(buffer);
}

function base64FromArrayBuffer(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    const sub = bytes.subarray(i, i + chunk);
    binary += String.fromCharCode.apply(null, sub);
  }
  return btoa(binary);
}
