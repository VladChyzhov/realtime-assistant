const { contextBridge, ipcRenderer } = require('electron');

// Безопасно экспортируем API для renderer процесса
contextBridge.exposeInMainWorld('electronAPI', {
  // Получение API ключа
  getApiKey: () => ipcRenderer.invoke('get-api-key'),
  
  // Получение текущей модели
  getCurrentModel: () => ipcRenderer.invoke('get-current-model'),
  
  // Получение источников захвата рабочего стола (включая системное аудио)
  getDesktopSources: (options = { types: ['screen', 'window'] }) => ipcRenderer.invoke('get-desktop-sources', options),

  // Запуск захвата звука
  startAudioCapture: () => ipcRenderer.invoke('start-audio-capture'),
  
  // Остановка захвата звука
  stopAudioCapture: () => ipcRenderer.invoke('stop-audio-capture'),

  // Отправка аудиочанка (PCM16 base64) в main процесс
  sendAudioChunk: (base64Pcm16) => ipcRenderer.send('audio-chunk', base64Pcm16),

  // Отправка событий VAD в main процесс
  sendVADEvent: (type, payload = {}) => ipcRenderer.send('vad-event', { type, ...payload }),
  
  // Слушатели событий
  on: (channel, callback) => {
    // Разрешаем только определенные каналы
    const validChannels = [
      'vad', 'transcript', 'response', 'error', 
      'connected', 'disconnected', 'stream-activated', 'stream-deactivated',
      'openai-ready', 'openai-stream-activated', 'openai-stream-deactivated',
      'model-changed', 'audio-capture-ready', 'audio-capture-started', 'audio-capture-stopped'
    ];
    
    if (!validChannels.includes(channel)) return;
    ipcRenderer.on(channel, (event, ...args) => callback(...args));
  },
  
  // Удаление слушателей
  removeAllListeners: (channel) => {
    const validChannels = [
      'vad', 'transcript', 'response', 'error',
      'connected', 'disconnected', 'stream-activated', 'stream-deactivated',
      'openai-ready', 'openai-stream-activated', 'openai-stream-deactivated',
      'model-changed', 'audio-capture-ready', 'audio-capture-started', 'audio-capture-stopped'
    ];
    
    if (validChannels.includes(channel)) {
      ipcRenderer.removeAllListeners(channel);
    }
  }
});

// Логирование для отладки
console.log('🔌 Preload скрипт загружен');
