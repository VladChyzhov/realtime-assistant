require('dotenv/config');
const { app, BrowserWindow, ipcMain, globalShortcut, desktopCapturer } = require('electron');
const path = require('path');
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const { createSystemAudioCapture } = require('./utils/audioCapture.js');
const { createVadProcessor } = require('./utils/vad.js');
const { createOpenAIStream } = require('./utils/openai.js');

let mainWindow;
let audioCapture = null;
let vadProcessor = null;
let openAIStream = null;
let expressApp;
let server;
let io;
// Убираем логику очереди/готовности renderer – шлём только в живое окно

// Создание Express сервера
function createServer() {
  expressApp = express();
  expressApp.use(express.json());
  expressApp.use(express.static(path.join(__dirname, 'public')));
  
  // CORS для браузера
  expressApp.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
  });
  
  // API endpoints
  expressApp.get('/api/status', (req, res) => {
    res.json({ 
      status: 'running', 
      audioCapture: !!audioCapture,
      vad: !!vadProcessor,
      openai: !!openAIStream,
      timestamp: Date.now()
    });
  });
  
  expressApp.post('/api/start', async (req, res) => {
    try {
      await startAudioCapture();
      res.json({ success: true, message: 'Захват звука запущен' });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  });
  
  expressApp.post('/api/stop', async (req, res) => {
    try {
      await stopAudioCapture();
      res.json({ success: true, message: 'Захват звука остановлен' });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  });
  
  expressApp.post('/api/switch-model', (req, res) => {
    const { model } = req.body;
    if (model && openAIStream) {
      openAIStream.switchModel(model);
      res.json({ success: true, message: `Модель переключена на ${model}` });
    } else {
      res.status(400).json({ success: false, error: 'Неверная модель или поток не активен' });
    }
  });
  
  expressApp.get('/api/stats', (req, res) => {
    const stats = {
      audioCapture: audioCapture ? audioCapture.getStats() : null,
      vad: vadProcessor ? vadProcessor.getStats() : null,
      openai: openAIStream ? openAIStream.getStats() : null,
      timestamp: Date.now()
    };
    res.json(stats);
  });
  
  server = http.createServer(expressApp);
  io = socketIo(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });
  
  // WebSocket события
  io.on('connection', (socket) => {
    console.log('🌐 Новое WebSocket подключение:', socket.id);
    
    // Отправляем текущий статус
    socket.emit('status', {
      audioCapture: !!audioCapture,
      vad: !!vadProcessor,
      openai: !!openAIStream
    });
    
    socket.on('disconnect', () => {
      console.log('🔌 WebSocket отключен:', socket.id);
    });
  });
  
  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => {
    console.log(`🚀 HTTP сервер запущен на порту ${PORT}`);
    console.log(`🌐 WebSocket сервер доступен на ws://localhost:${PORT}`);
  });
}

// Безопасная отправка событий в renderer
function sendToRenderer(channel, data) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    try {
      const wc = mainWindow.webContents;
      if (wc && !wc.isDestroyed()) {
        wc.send(channel, data);
        return;
      }
    } catch (err) {
      console.warn(`⚠️ Не удалось отправить данные в рендерер: ${err.message}`);
    }
  }
  console.warn('⚠️ Рендерер недоступен, сообщение пропущено:', channel);
}

// Запуск захвата системного звука
async function startAudioCapture() {
  try {
    console.log('🎵 Запуск захвата системного звука...');
    
    // Получаем API ключ
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error('OPENAI_API_KEY не установлен в .env файле');
    }
    
    // Получаем модель
    const model = process.env.OPENAI_MODEL || 'gpt-4o-realtime-preview';
    
    // Создаем захват системного звука (опционально, для внутреннего теста)
    // В проде аудио поступает из renderer через IPC 'audio-chunk'
    try {
      audioCapture = await createSystemAudioCapture();
      // Создаем VAD процессор (опционально)
      vadProcessor = createVadProcessor(audioCapture.processedStream, {
        speechThreshold: parseFloat(process.env.VAD_SPEECH_THRESHOLD) || 0.008,
        silenceThreshold: parseFloat(process.env.VAD_SILENCE_THRESHOLD) || 0.003,
        silenceFrames: parseInt(process.env.VAD_SILENCE_FRAMES) || 15
      });
    } catch {}
    
    // Создаем OpenAI поток (Realtime по WebSocket)
    openAIStream = createOpenAIStream(model, apiKey, vadProcessor, {
      systemPrompt: `Ты — мой AI-помощник для живых собеседований и звонков.

Твоя задача:
1. Слушать речь собеседника и транскрибировать её в реальном времени
2. Анализировать содержание и контекст разговора
3. Генерировать 3 варианта ответа на разных языках

Формат ответов:
RU: [Полный, содержательный ответ на русском языке]
EN: [A full, detailed answer in English]
SV: [Ett fullständigt svar på svenska]

Требования:
- Отвечай кратко, но по существу
- Учитывай контекст предыдущих фраз
- Будь полезным, дружелюбным и профессиональным
- Адаптируй стиль под тип разговора (деловой, дружеский, формальный)
- Предлагай конкретные действия или рекомендации когда уместно`
    });
    
    // Настраиваем обработчики событий
    setupEventHandlers();
    
    // Запускаем внутренний мок-захват (не обязателен)
    if (audioCapture && typeof audioCapture.start === 'function') {
      await audioCapture.start();
    }
    
    console.log('✅ Захват системного звука успешно запущен');
    
    // Уведомляем WebSocket клиентов
    if (io) {
      io.emit('audio-capture-started', {
        message: 'Захват системного звука запущен',
        timestamp: Date.now()
      });
    }
    
  } catch (error) {
    console.error('❌ Ошибка запуска захвата звука:', error);
    throw error;
  }
}

// Настройка обработчиков событий
function setupEventHandlers() {
  // Даже если нет локального audioCapture/VAD, подписываемся на OpenAI
  
  // Обработчики захвата звука
  if (audioCapture) {
    audioCapture.on('ready', (stream) => {
      console.log('🎵 Захват звука готов');
      const payload = { timestamp: Date.now() };
      if (io) io.emit('audio-capture-ready', payload);
      sendToRenderer('audio-capture-ready', payload);
    });

    audioCapture.on('audio-data', (data) => {
      // Передаем аудио данные в OpenAI поток (если используем внутренний захват)
      if (openAIStream) {
        openAIStream.sendAudioData(data);
      }

      const payload = { size: data?.size || 0, timestamp: Date.now() };
      if (io) io.emit('audio-data', payload);
      sendToRenderer('audio-data', payload);
    });

    audioCapture.on('error', (error) => {
      console.error('❌ Ошибка захвата звука:', error);
      const payload = { error: error.message, timestamp: Date.now() };
      if (io) io.emit('audio-capture-error', payload);
      sendToRenderer('error', payload);
    });
  }
  
  // Обработчики VAD
  if (vadProcessor) {
    vadProcessor.on('ready', () => {
      console.log('🎤 VAD процессор готов');
      const payload = { timestamp: Date.now() };
      if (io) io.emit('vad-ready', payload);
      sendToRenderer('vad', { type: 'ready', ...payload });
    });

    vadProcessor.on('speech-start', (data) => {
      console.log('🎙️ Речь обнаружена:', data);
      const payload = { ...data, timestamp: Date.now() };
      if (io) io.emit('speech-start', payload);
      sendToRenderer('vad', { type: 'speech-start', ...payload });
    });

    vadProcessor.on('speech-end', (data) => {
      console.log('🔇 Речь завершена:', data);
      const payload = { ...data, timestamp: Date.now() };
      if (io) io.emit('speech-end', payload);
      sendToRenderer('vad', { type: 'speech-end', ...payload });
    });

    vadProcessor.on('error', (error) => {
      console.error('❌ Ошибка VAD:', error);
      const payload = { error: error.message, timestamp: Date.now() };
      if (io) io.emit('vad-error', payload);
      sendToRenderer('error', payload);
    });
  }
  
  // Обработчики OpenAI
  if (openAIStream) openAIStream.on('ready', () => {
    console.log('🤖 OpenAI поток готов');
    const payload = { timestamp: Date.now() };
    if (io) io.emit('openai-ready', payload);
    sendToRenderer('openai-ready', payload);
  });
  
  if (openAIStream) openAIStream.on('stream-activated', () => {
    console.log('🎙️ OpenAI поток активирован');
    const payload = { timestamp: Date.now() };
    if (io) io.emit('openai-stream-activated', payload);
    sendToRenderer('openai-stream-activated', payload);
  });
  
  if (openAIStream) openAIStream.on('stream-deactivated', () => {
    console.log('🔇 OpenAI поток деактивирован');
    const payload = { timestamp: Date.now() };
    if (io) io.emit('openai-stream-deactivated', payload);
    sendToRenderer('openai-stream-deactivated', payload);
  });
  
  if (openAIStream) openAIStream.on('transcript', (data) => {
    console.log('📝 Транскрипт получен:', data.text);
    const payload = { ...data, timestamp: Date.now() };
    if (io) io.emit('transcript', payload);
    sendToRenderer('transcript', payload);
  });
  
  if (openAIStream) openAIStream.on('response', (data) => {
    console.log('💬 Ответ получен:', data.parsed);
    const payload = { ...data, timestamp: Date.now() };
    if (io) io.emit('response', payload);
    sendToRenderer('response', payload);
  });
  
  if (openAIStream) openAIStream.on('error', (error) => {
    console.error('❌ Ошибка OpenAI:', error);
    const payload = { error: error.message, timestamp: Date.now() };
    if (io) io.emit('openai-error', payload);
    sendToRenderer('error', payload);
  });
  
  if (openAIStream) openAIStream.on('model-changed', (model) => {
    console.log('🔄 Модель изменена:', model);
    const payload = { model, timestamp: Date.now() };
    if (io) io.emit('model-changed', payload);
    sendToRenderer('model-changed', payload);
  });
}

// Остановка захвата системного звука
async function stopAudioCapture() {
  try {
    console.log('🛑 Остановка захвата системного звука...');
    
    // Останавливаем компоненты
    if (openAIStream) {
      openAIStream.close();
      openAIStream = null;
    }
    
    if (vadProcessor) {
      vadProcessor.close();
      vadProcessor = null;
    }
    
    if (audioCapture) {
      audioCapture.stop();
      audioCapture = null;
    }
    
    console.log('✅ Захват системного звука остановлен');
    
    // Уведомляем WebSocket клиентов
    if (io) {
      io.emit('audio-capture-stopped', {
        message: 'Захват системного звука остановлен',
        timestamp: Date.now()
      });
    }
    
  } catch (error) {
    console.error('❌ Ошибка остановки захвата звука:', error);
    throw error;
  }
}

// Создание главного окна
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    title: 'Realtime AI Assistant',
    icon: path.join(__dirname, 'public', 'icon.png'),
    show: false
  });
  
  // Загружаем HTML файл
  mainWindow.loadFile('index.html');
  
  // Показываем окно когда готово
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    console.log('🪟 Главное окно создано и показано');
  });
  
  // Обработка закрытия окна
  mainWindow.on('closed', () => {
    // Останавливаем все фоновые процессы/стримы
    stopAudioCapture().catch(() => {});
    mainWindow = null;
  });
  
  // Открываем DevTools в режиме разработки
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools();
  }

  // Если рендерер перезагружается/исчезает – гасим стриминг
  mainWindow.webContents.on('did-start-loading', () => {
    stopAudioCapture().catch(() => {});
  });
  mainWindow.webContents.on('render-process-gone', () => {
    stopAudioCapture().catch(() => {});
  });
}

// Регистрация глобальных горячих клавиш
function registerGlobalShortcuts() {
  // Ctrl+Shift+A для запуска/остановки захвата
  globalShortcut.register('CommandOrControl+Shift+A', async () => {
    try {
      if (audioCapture && audioCapture.isRecording) {
        await stopAudioCapture();
      } else {
        await startAudioCapture();
      }
    } catch (error) {
      console.error('❌ Ошибка переключения захвата:', error);
    }
  });
  
  // Ctrl+Shift+M для переключения модели
  globalShortcut.register('CommandOrControl+Shift+M', () => {
    if (openAIStream) {
      const currentModel = openAIStream.model;
      const newModel = currentModel === 'gpt-4o-realtime-preview' 
        ? 'gpt-4o-mini-realtime-preview' 
        : 'gpt-4o-realtime-preview';
      
      openAIStream.switchModel(newModel);
    }
  });
  
  console.log('⌨️ Глобальные горячие клавиши зарегистрированы');
}

// Обработчики IPC
ipcMain.handle('get-status', () => {
  return {
    audioCapture: !!audioCapture,
    vad: !!vadProcessor,
    openai: !!openAIStream,
    timestamp: Date.now()
  };
});

// Источники экрана/окна для renderer (для getUserMedia с системным аудио)
ipcMain.handle('get-desktop-sources', async (event, options) => {
  const sources = await desktopCapturer.getSources({
    types: options?.types || ['screen', 'window'],
    thumbnailSize: { width: 160, height: 90 },
    fetchWindowIcons: true
  });
  return sources.map(s => ({ id: s.id, name: s.name }));
});

ipcMain.handle('get-api-key', () => {
  // Возвращаем API ключ из переменных окружения
  return process.env.OPENAI_API_KEY || 'sk-your-api-key-here';
});

ipcMain.handle('start-audio-capture', async () => {
  try {
    await startAudioCapture();
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('stop-audio-capture', async () => {
  try {
    await stopAudioCapture();
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('switch-model', (event, model) => {
  if (openAIStream) {
    openAIStream.switchModel(model);
    return { success: true };
  }
  return { success: false, error: 'OpenAI поток не активен' };
});

ipcMain.handle('get-current-model', () => {
  if (openAIStream) {
    return openAIStream.model;
  }
  return process.env.OPENAI_MODEL || 'gpt-4o-realtime-preview';
});

// Прием аудио чанков (PCM16 base64) от renderer
ipcMain.on('audio-chunk', (event, base64Pcm16) => {
  if (openAIStream && base64Pcm16) {
    try {
      openAIStream.ingestBase64Pcm16(base64Pcm16);
    } catch (error) {
      console.error('❌ Ошибка приема аудиочанка:', error);
    }
  }
});

// События VAD от renderer
ipcMain.on('vad-event', (event, payload) => {
  if (io) io.emit('vad', payload);
  if (!openAIStream || !payload?.type) return;
  try {
    if (payload.type === 'speech-start') {
      openAIStream.handleVADEvent('speech-start');
    } else if (payload.type === 'speech-end') {
      openAIStream.handleVADEvent('speech-end');
    }
  } catch (error) {
    console.error('❌ Ошибка обработки VAD события:', error);
  }
});

// Убираем обработчик renderer-ready – больше не нужен

// Обработчики событий приложения
app.whenReady().then(() => {
  console.log('🚀 Приложение готово к запуску');
  
  // Создаем сервер
  createServer();
  
  // Создаем окно
  createWindow();
  
  // Регистрируем горячие клавиши
  registerGlobalShortcuts();
  
  // Обработка активации приложения
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// Обработка закрытия приложения
app.on('window-all-closed', async () => {
  // Останавливаем захват звука перед закрытием
  if (audioCapture) {
    await stopAudioCapture();
  }
  
  // Закрываем сервер
  if (server) {
    server.close();
  }
  
  // Выходим из приложения
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Обработка выхода из приложения
app.on('before-quit', async () => {
  // Останавливаем захват звука
  if (audioCapture) {
    await stopAudioCapture();
  }
  
  // Отменяем регистрацию горячих клавиш
  globalShortcut.unregisterAll();
});

// Обработка ошибок
process.on('uncaughtException', (error) => {
  console.error('❌ Необработанная ошибка:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Необработанное отклонение промиса:', reason);
});
